import React, { useState, useEffect } from 'react';
import { HeroSection } from './components/HeroSection';
import { LoadingScreen } from './components/LoadingScreen';
import { ErrorScreen } from './components/ErrorScreen';
import { WrappedResults } from './components/WrappedResults';
import { tzktApi } from './services/tzktApi';
import { WalletStats } from './types';

type AppState = 'hero' | 'loading' | 'results' | 'error';

function App() {
  const [state, setState] = useState<AppState>('hero');
  const [walletAddress, setWalletAddress] = useState('');
  const [stats, setStats] = useState<WalletStats | null>(null);
  const [error, setError] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    // Check URL parameters on load
    const urlParams = new URLSearchParams(window.location.search);
    const wallet = urlParams.get('wallet');
    
    if (wallet) {
      setWalletAddress(wallet);
      handleWalletSubmit(wallet);
    }
  }, []);

  const handleWalletSubmit = async (address: string) => {
    setState('loading');
    setWalletAddress(address);
    setError('');

    // Update URL
    const newUrl = `${window.location.pathname}?wallet=${encodeURIComponent(address)}`;
    window.history.pushState({}, '', newUrl);

    try {
      const walletStats = await tzktApi.getWalletStats(address);
      setStats(walletStats);
      setState('results');
    } catch (err) {
      console.error('Error fetching wallet stats:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch wallet data');
      setState('error');
    }
  };

  const refreshWalletStats = async () => {
    if (!walletAddress || isRefreshing) return;
    
    setIsRefreshing(true);
    setError('');

    try {
      const walletStats = await tzktApi.getWalletStats(walletAddress);
      setStats(walletStats);
    } catch (err) {
      console.error('Error refreshing wallet stats:', err);
      setError(err instanceof Error ? err.message : 'Failed to refresh wallet data');
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleRetry = () => {
    if (walletAddress) {
      handleWalletSubmit(walletAddress);
    } else {
      setState('hero');
    }
  };

  const handleNewSearch = () => {
    setState('hero');
    setWalletAddress('');
    setStats(null);
    setError('');
    setIsRefreshing(false);
    window.history.pushState({}, '', window.location.pathname);
  };

  switch (state) {
    case 'loading':
      return <LoadingScreen />;
    
    case 'error':
      return <ErrorScreen error={error} onRetry={handleRetry} />;
    
    case 'results':
      return stats ? (
        <WrappedResults 
          stats={stats} 
          walletAddress={walletAddress} 
          onRefreshStats={refreshWalletStats}
          isRefreshing={isRefreshing}
        />
      ) : (
        <ErrorScreen error="No data available" onRetry={handleRetry} />
      );
    
    default:
      return <HeroSection onSubmit={handleWalletSubmit} />;
  }
}

export default App;