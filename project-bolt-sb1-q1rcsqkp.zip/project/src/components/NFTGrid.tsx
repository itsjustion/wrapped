import React from 'react';
import { Image, Package } from 'lucide-react';
import { TezosToken } from '../types';

interface NFTGridProps {
  nfts: TezosToken[];
  totalCount: number;
}

export const NFTGrid: React.FC<NFTGridProps> = ({ nfts, totalCount }) => {
  const getImageUrl = (token: TezosToken): string | null => {
    const metadata = token.token.metadata;
    if (metadata?.thumbnailUri) {
      return metadata.thumbnailUri.replace('ipfs://', 'https://ipfs.io/ipfs/');
    }
    if (metadata?.displayUri) {
      return metadata.displayUri.replace('ipfs://', 'https://ipfs.io/ipfs/');
    }
    if (metadata?.image) {
      return metadata.image.replace('ipfs://', 'https://ipfs.io/ipfs/');
    }
    return null;
  };

  const getObjktUrl = (token: TezosToken): string => {
    return `https://objkt.com/asset/${token.token.contract.address}/${token.token.tokenId}`;
  };

  return (
    <div className="card">
      <div className="flex items-center space-x-3 mb-6">
        <Package className="w-6 h-6 text-tezos" />
        <div>
          <h3 className="text-xl font-bold text-white">NFT Collection</h3>
          <p className="text-gray-400">{totalCount} NFTs Collected</p>
        </div>
      </div>

      {nfts.length > 0 ? (
        <div className="grid grid-cols-3 gap-4">
          {nfts.map((token, index) => {
            const imageUrl = getImageUrl(token);
            const objktUrl = getObjktUrl(token);
            
            return (
              <a
                key={`${token.token.contract.address}-${token.token.tokenId}`}
                href={objktUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="aspect-square rounded-xl overflow-hidden bg-dark border border-dark-border hover:border-tezos transition-all duration-300 group cursor-pointer"
              >
                {imageUrl ? (
                  <img
                    src={imageUrl}
                    alt={token.token.metadata?.name || `NFT #${token.token.tokenId}`}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                      e.currentTarget.nextElementSibling?.classList.remove('hidden');
                    }}
                  />
                ) : null}
                <div className={`w-full h-full flex items-center justify-center ${imageUrl ? 'hidden' : ''}`}>
                  <Image className="w-8 h-8 text-gray-400 group-hover:text-tezos transition-colors duration-300" />
                </div>
              </a>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12 text-gray-400">
          <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No NFTs found in this wallet</p>
        </div>
      )}
    </div>
  );
};