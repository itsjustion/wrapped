import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { formatXTZ } from '../utils/validation';

interface TransactionChartProps {
  xtzIn: number;
  xtzOut: number;
}

export const TransactionChart: React.FC<TransactionChartProps> = ({ xtzIn, xtzOut }) => {
  const maxValue = Math.max(xtzIn, xtzOut);
  const inPercentage = maxValue > 0 ? (xtzIn / maxValue) * 100 : 0;
  const outPercentage = maxValue > 0 ? (xtzOut / maxValue) * 100 : 0;

  return (
    <div className="card">
      <h3 className="text-xl font-bold text-white mb-6">XTZ Volume</h3>
      
      <div className="space-y-6">
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-gray-300">Received</span>
            </div>
            <span className="text-lg font-bold text-white">{formatXTZ(xtzIn)} XTZ</span>
          </div>
          <div className="w-full bg-dark rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-tezos h-3 rounded-full transition-all duration-1000 ease-out"
              style={{ width: `${inPercentage}%` }}
            ></div>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-5 h-5 text-red-400" />
              <span className="text-gray-300">Sent</span>
            </div>
            <span className="text-lg font-bold text-white">{formatXTZ(xtzOut)} XTZ</span>
          </div>
          <div className="w-full bg-dark rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-red-500 to-orange-400 h-3 rounded-full transition-all duration-1000 ease-out delay-300"
              style={{ width: `${outPercentage}%` }}
            ></div>
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-dark rounded-xl">
        <div className="text-center">
          <div className="text-2xl font-bold text-white mb-1">
            {formatXTZ(Math.abs(xtzIn - xtzOut))} XTZ
          </div>
          <div className="text-sm text-gray-400">
            Net {xtzIn > xtzOut ? 'Received' : 'Sent'}
          </div>
        </div>
      </div>
    </div>
  );
};