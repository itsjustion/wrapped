import React, { useState } from 'react';
import { Code, ExternalLink, ChevronDown, ChevronUp } from 'lucide-react';
import { UniqueContract } from '../types';
import { formatAddress } from '../utils/validation';

interface ContractsSectionProps {
  contracts: UniqueContract[];
}

export const ContractsSection: React.FC<ContractsSectionProps> = ({ contracts }) => {
  const [showAllContracts, setShowAllContracts] = useState(true);
  
  const getContractUrl = (address: string) => `https://tzkt.io/${address}`;
  const remainingCount = contracts.length - 5;

  return (
    <div className="card">
      <div className="flex items-center space-x-3 mb-6">
        <Code className="w-6 h-6 text-tezos" />
        <div className="flex-1">
          <div className="flex items-center space-x-3">
            <h3 className="text-xl font-bold text-white">Smart Contracts</h3>
            <span className="bg-tezos/20 text-tezos px-3 py-1 rounded-full text-sm font-semibold">
              {contracts.length}
            </span>
          </div>
          <p className="text-gray-400">dApps you've interacted with</p>
        </div>
      </div>

      {contracts.length > 0 ? (
        <div className="space-y-3">
          <div className={`space-y-3 transition-all duration-500 ease-in-out custom-scrollbar pr-2 ${
            showAllContracts 
              ? 'max-h-none overflow-y-visible' 
              : 'max-h-[300px] overflow-y-hidden'
          }`}>
            {contracts.map((contract, index) => (
              <a
                key={index}
                href={getContractUrl(contract.address)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-3 bg-dark rounded-xl hover:bg-dark-border transition-colors duration-200 group cursor-pointer"
              >
                <span className="text-white font-medium group-hover:text-tezos transition-colors duration-200">
                  {contract.alias || formatAddress(contract.address)}
                </span>
                <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-tezos transition-colors duration-200" />
              </a>
            ))}
          </div>
          
          {remainingCount > 0 && (
            <button
              onClick={() => setShowAllContracts(!showAllContracts)}
              className="w-full text-center text-gray-400 text-sm mt-4 py-2 hover:text-tezos transition-colors duration-200 flex items-center justify-center space-x-2 group"
            >
              <span>
                {showAllContracts 
                  ? 'Show less' 
                  : `+${remainingCount} more contracts`
                }
              </span>
              {showAllContracts ? (
                <ChevronUp className="w-4 h-4 group-hover:text-tezos transition-colors duration-200" />
              ) : (
                <ChevronDown className="w-4 h-4 group-hover:text-tezos transition-colors duration-200" />
              )}
            </button>
          )}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-400">
          <Code className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>No smart contract interactions found</p>
        </div>
      )}
    </div>
  );
};