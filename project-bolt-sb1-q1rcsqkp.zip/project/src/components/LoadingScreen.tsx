import React from 'react';
import { Loader2, Sparkles } from 'lucide-react';

export const LoadingScreen: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-dark via-dark to-dark-lighter">
      <div className="text-center animate-fade-in">
        <div className="relative mb-8">
          <Sparkles className="w-16 h-16 text-tezos mx-auto animate-bounce-gentle" />
          <Loader2 className="w-8 h-8 text-white absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-spin" />
        </div>
        
        <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-white to-tezos bg-clip-text text-transparent">
          Analyzing Your Tezos Journey
        </h2>
        
        <div className="space-y-2 text-gray-300">
          <p className="animate-pulse">Fetching your transaction history...</p>
          <p className="animate-pulse delay-150">Counting your NFT collection...</p>
          <p className="animate-pulse delay-300">Analyzing smart contract interactions...</p>
        </div>
        
        <div className="mt-8 flex justify-center">
          <div className="flex space-x-2">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-3 h-3 bg-tezos rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.1}s` }}
              ></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};