import React, { useState } from 'react';
import { Search, Sparkles } from 'lucide-react';
import { validateTezosAddress } from '../utils/validation';

interface HeroSectionProps {
  onSubmit: (address: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onSubmit }) => {
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!address.trim()) {
      setError('Please enter a wallet address');
      return;
    }

    if (!validateTezosAddress(address.trim())) {
      setError('Please enter a valid Tezos wallet address (tz1, tz2, tz3, or KT1)');
      return;
    }

    onSubmit(address.trim());
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-dark via-dark to-dark-lighter">
      <div className="absolute inset-0 bg-gradient-to-r from-tezos/5 to-blue-500/5"></div>
      
      <div className="relative max-w-4xl mx-auto text-center animate-fade-in">
        <div className="mb-8 animate-bounce-gentle">
          <Sparkles className="w-16 h-16 text-tezos mx-auto mb-6" />
        </div>
        
        <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-white via-tezos to-blue-400 bg-clip-text text-transparent animate-slide-up">
          Your Tezos Wrapped
        </h1>
        
        <h3 className="text-xl md:text-2xl text-gray-300 mb-12 max-w-2xl mx-auto leading-relaxed animate-slide-up delay-200">
          See your journey on Tezos — from your first transaction to your most minted NFT.
        </h3>

        <form onSubmit={handleSubmit} className="max-w-lg mx-auto animate-slide-up delay-400">
          <div className="relative mb-4">
            <label htmlFor="wallet" className="block text-left text-sm font-medium text-gray-300 mb-2">
              Enter your Tezos wallet address
            </label>
            <div className="relative">
              <input
                id="wallet"
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="tz1... or KT1..."
                className="input-field w-full pr-12"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            </div>
            {error && (
              <p className="text-red-400 text-sm mt-2 text-left">{error}</p>
            )}
          </div>
          
          <button type="submit" className="btn-primary w-full text-lg animate-glow">
            Get My Wrapped
          </button>
        </form>

        <div className="mt-16 text-gray-400 text-sm">
          <p>Powered by TzKT API • Built with ❤️ for the Tezos community</p>
        </div>
      </div>
    </div>
  );
};