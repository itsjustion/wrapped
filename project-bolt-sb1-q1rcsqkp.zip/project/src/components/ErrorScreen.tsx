import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

interface ErrorScreenProps {
  error: string;
  onRetry: () => void;
}

export const ErrorScreen: React.FC<ErrorScreenProps> = ({ error, onRetry }) => {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-dark via-dark to-dark-lighter">
      <div className="text-center max-w-md mx-auto animate-fade-in">
        <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-6" />
        
        <h2 className="text-3xl font-bold mb-4 text-white">
          Oops! Something went wrong
        </h2>
        
        <p className="text-gray-300 mb-8 leading-relaxed">
          {error === 'Failed to fetch account: Not Found' 
            ? "Looks like this wallet hasn't been active yet! Make sure you've entered a valid Tezos address."
            : error
          }
        </p>
        
        <button 
          onClick={onRetry}
          className="btn-primary inline-flex items-center space-x-2"
        >
          <RefreshCw className="w-5 h-5" />
          <span>Try Again</span>
        </button>
      </div>
    </div>
  );
};