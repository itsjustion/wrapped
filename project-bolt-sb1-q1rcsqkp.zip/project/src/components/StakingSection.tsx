import React from 'react';
import { Shield, Award, Coins, Users, RefreshCw } from 'lucide-react';
import { TezosAccount } from '../types';
import { formatAddress, formatXTZ } from '../utils/validation';

interface StakingSectionProps {
  account: TezosAccount;
  onRefresh: () => void;
  isRefreshing: boolean;
}

export const StakingSection: React.FC<StakingSectionProps> = ({ 
  account, 
  onRefresh, 
  isRefreshing 
}) => {
  const delegatedAmount = account.balance / 1_000_000; // Convert from mutez to XTZ
  const stakedAmount = account.stakedBalance ? account.stakedBalance / 1_000_000 : 0;
  const unstakedAmount = account.unstakedBalance ? account.unstakedBalance / 1_000_000 : 0;
  
  const hasDelegate = !!account.delegate;
  const hasStaking = stakedAmount > 0;
  const hasUnstaking = unstakedAmount > 0;

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Shield className="w-6 h-6 text-tezos" />
          <div>
            <h3 className="text-xl font-bold text-white">Staking & Delegation</h3>
            <p className="text-gray-400">Your participation in Tezos consensus</p>
          </div>
        </div>
        
        <button
          onClick={onRefresh}
          disabled={isRefreshing}
          className="p-2 rounded-lg bg-dark border border-dark-border hover:border-tezos transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed group"
          title="Refresh staking data"
        >
          <RefreshCw 
            className={`w-5 h-5 text-gray-400 group-hover:text-tezos transition-colors duration-200 ${
              isRefreshing ? 'animate-spin' : ''
            }`} 
          />
        </button>
      </div>

      <div className="space-y-6">
        {/* Delegation Section */}
        {hasDelegate ? (
          <div className="bg-gradient-to-r from-blue-500/10 to-tezos/10 rounded-xl p-6 border border-blue-500/20">
            <div className="flex items-center space-x-3 mb-4">
              <Users className="w-5 h-5 text-blue-400" />
              <h4 className="text-lg font-semibold text-white">Delegation</h4>
            </div>
            
            <div className="space-y-4">
              <div className="text-center bg-dark/50 rounded-lg p-4">
                <div className="text-lg font-bold text-white mb-2">
                  {account.delegate.alias || formatAddress(account.delegate.address)}
                </div>
                <div className="text-sm text-gray-300">Your Tezos Baker</div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Coins className="w-4 h-4 text-blue-400" />
                  <span className="text-gray-300">Delegated Amount</span>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-white">
                    {formatXTZ(delegatedAmount)} XTZ
                  </div>
                  <div className="text-sm text-gray-400">Liquid & earning</div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-dark rounded-xl p-6 border border-dark-border">
            <div className="flex items-center space-x-3 mb-4">
              <Users className="w-5 h-5 text-gray-400" />
              <h4 className="text-lg font-semibold text-white">Delegation</h4>
            </div>
            <div className="text-center py-4 text-gray-400">
              <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Not currently delegating</p>
            </div>
          </div>
        )}

        {/* Staking Section */}
        {hasStaking ? (
          <div className="bg-gradient-to-r from-tezos/10 to-green-500/10 rounded-xl p-6 border border-tezos/20">
            <div className="flex items-center space-x-3 mb-4">
              <Award className="w-5 h-5 text-tezos" />
              <h4 className="text-lg font-semibold text-white">Direct Staking</h4>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-tezos" />
                <span className="text-gray-300">Staked Amount</span>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold text-white">
                  {formatXTZ(stakedAmount)} XTZ
                </div>
                <div className="text-sm text-gray-400">Locked & securing</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-dark rounded-xl p-6 border border-dark-border">
            <div className="flex items-center space-x-3 mb-4">
              <Award className="w-5 h-5 text-gray-400" />
              <h4 className="text-lg font-semibold text-white">Direct Staking</h4>
            </div>
            <div className="text-center py-4 text-gray-400">
              <Shield className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No direct staking active</p>
            </div>
          </div>
        )}

        {/* Unstaking Section (only show if there's unstaking in progress) */}
        {hasUnstaking && (
          <div className="bg-gradient-to-r from-orange-500/10 to-red-500/10 rounded-xl p-6 border border-orange-500/20">
            <div className="flex items-center space-x-3 mb-4">
              <RefreshCw className="w-5 h-5 text-orange-400" />
              <h4 className="text-lg font-semibold text-white">Unstaking</h4>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Coins className="w-4 h-4 text-orange-400" />
                <span className="text-gray-300">Unstaking Amount</span>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold text-white">
                  {formatXTZ(unstakedAmount)} XTZ
                </div>
                <div className="text-sm text-gray-400">Being unlocked</div>
              </div>
            </div>
          </div>
        )}

        {/* Info Section */}
        {!hasDelegate && !hasStaking && (
          <div className="text-center py-8 text-gray-400">
            <Shield className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p className="mb-2">Start participating in Tezos consensus!</p>
            <p className="text-sm">Delegate to earn rewards or stake directly for higher yields.</p>
          </div>
        )}
      </div>
    </div>
  );
};