import React from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ReactNode;
  className?: string;
}

export const StatsCard: React.FC<StatsCardProps> = ({ 
  title, 
  value, 
  subtitle, 
  icon, 
  className = '' 
}) => {
  return (
    <div className={`card hover:scale-105 transition-transform duration-300 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-gray-300 text-sm font-medium">{title}</h3>
        {icon && <div className="text-tezos">{icon}</div>}
      </div>
      
      <div className="text-3xl font-bold text-white mb-1">
        {value}
      </div>
      
      {subtitle && (
        <p className="text-gray-400 text-sm">{subtitle}</p>
      )}
    </div>
  );
};