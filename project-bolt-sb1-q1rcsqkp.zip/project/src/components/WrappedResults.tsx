import React from 'react';
import { Download, Twitter, Calendar, Activity, Coins } from 'lucide-react';
import { WalletStats } from '../types';
import { StatsCard } from './StatsCard';
import { TransactionChart } from './TransactionChart';
import { NFTGrid } from './NFTGrid';
import { ContractsSection } from './ContractsSection';
import { StakingSection } from './StakingSection';
import { downloadWrappedImage, shareOnTwitter } from '../utils/share';
import { formatAddress, formatXTZ } from '../utils/validation';

interface WrappedResultsProps {
  stats: WalletStats;
  walletAddress: string;
  onRefreshStats: () => void;
  isRefreshing: boolean;
}

export const WrappedResults: React.FC<WrappedResultsProps> = ({ 
  stats, 
  walletAddress, 
  onRefreshStats, 
  isRefreshing 
}) => {
  const handleDownload = () => {
    downloadWrappedImage('wrapped-infographic', `${walletAddress}-wrapped.png`);
  };

  const handleShare = () => {
    shareOnTwitter({
      txCount: stats.txCount,
      xtzIn: stats.xtzIn,
      nftCount: stats.nftCount
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark to-dark-lighter py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-white via-tezos to-blue-400 bg-clip-text text-transparent">
            Your Tezos Wrapped
          </h1>
          <p className="text-gray-300 text-lg">
            {stats.account.alias || formatAddress(walletAddress)} • On Tezos since {stats.firstActivity}
          </p>
        </div>

        {/* Infographic Content */}
        <div id="wrapped-infographic" className="space-y-8 animate-slide-up">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatsCard
              title="Total Transactions"
              value={stats.txCount.toLocaleString()}
              subtitle="All-time activity"
              icon={<Activity className="w-6 h-6" />}
            />
            <StatsCard
              title="Years on Tezos"
              value={new Date().getFullYear() - stats.firstActivity + 1}
              subtitle={`Since ${stats.firstActivity}`}
              icon={<Calendar className="w-6 h-6" />}
            />
            <StatsCard
              title="Current Balance"
              value={`${formatXTZ(stats.account.balance / 1_000_000)} XTZ`}
              subtitle="Your holdings"
              icon={<Coins className="w-6 h-6" />}
            />
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <TransactionChart xtzIn={stats.xtzIn} xtzOut={stats.xtzOut} />
            <NFTGrid nfts={stats.topNFTs} totalCount={stats.nftCount} />
            <ContractsSection contracts={stats.uniqueContracts} />
            <StakingSection 
              account={stats.account} 
              onRefresh={onRefreshStats}
              isRefreshing={isRefreshing}
            />
          </div>
        </div>

        {/* Share & Download Section */}
        <div className="mt-12 text-center animate-slide-up delay-300">
          <div className="card max-w-md mx-auto">
            <h3 className="text-xl font-bold text-white mb-6">Share Your Wrapped</h3>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={handleDownload}
                className="btn-secondary flex-1 inline-flex items-center justify-center space-x-2"
              >
                <Download className="w-5 h-5" />
                <span>Download PNG</span>
              </button>
              
              <button
                onClick={handleShare}
                className="btn-primary flex-1 inline-flex items-center justify-center space-x-2"
              >
                <Twitter className="w-5 h-5" />
                <span>Share on X</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 text-center text-gray-400 text-sm">
          <p>Built with ❤️ for the Tezos community • Powered by TzKT API</p>
        </div>
      </div>
    </div>
  );
};