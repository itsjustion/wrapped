export interface TezosAccount {
  address: string;
  alias?: string;
  balance: number;
  stakedBalance?: number;
  unstakedBalance?: number;
  firstActivityTime: string;
  lastActivityTime: string;
  delegate?: {
    address: string;
    alias?: string;
  };
}

export interface TezosTransaction {
  id: number;
  level: number;
  timestamp: string;
  sender: {
    address: string;
    alias?: string;
  };
  target: {
    address: string;
    alias?: string;
  };
  amount: number;
  parameter?: any;
}

export interface TezosToken {
  id: number;
  balance: string;
  token: {
    id: number;
    contract: {
      address: string;
      alias?: string;
    };
    tokenId: string;
    standard: string;
    metadata?: {
      name?: string;
      description?: string;
      image?: string;
      thumbnailUri?: string;
      displayUri?: string;
    };
  };
}

export interface UniqueContract {
  address: string;
  alias?: string;
}

export interface WalletStats {
  account: TezosAccount;
  txCount: number;
  xtzIn: number;
  xtzOut: number;
  firstActivity: number;
  nftCount: number;
  uniqueContracts: UniqueContract[];
  topNFTs: TezosToken[];
  stakedBalance?: number;
  unstakedBalance?: number;
}