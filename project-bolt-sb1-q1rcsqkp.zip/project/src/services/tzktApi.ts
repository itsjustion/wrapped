import { TezosAccount, TezosTransaction, TezosToken, WalletStats, UniqueContract } from '../types';

const BASE_URL = 'https://api.tzkt.io/v1';

class TzKTApiService {
  async getAccount(address: string): Promise<TezosAccount> {
    const response = await fetch(`${BASE_URL}/accounts/${address}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch account: ${response.statusText}`);
    }
    return response.json();
  }

  async getTransactions(address: string): Promise<TezosTransaction[]> {
    const response = await fetch(
      `${BASE_URL}/operations/transactions?anyof.sender.target=${address}&limit=10000&sort.desc=id`
    );
    if (!response.ok) {
      throw new Error(`Failed to fetch transactions: ${response.statusText}`);
    }
    return response.json();
  }

  async getTokenBalances(address: string): Promise<TezosToken[]> {
    const response = await fetch(
      `${BASE_URL}/tokens/balances?account=${address}&limit=1000&sort.desc=id`
    );
    if (!response.ok) {
      throw new Error(`Failed to fetch tokens: ${response.statusText}`);
    }
    return response.json();
  }

  async getWalletStats(address: string): Promise<WalletStats> {
    try {
      const [account, transactions, tokens] = await Promise.all([
        this.getAccount(address),
        this.getTransactions(address),
        this.getTokenBalances(address)
      ]);

      const firstActivity = new Date(account.firstActivityTime).getFullYear();
      const txCount = transactions.length;
      
      const xtzIn = transactions
        .filter(tx => tx.target?.address === address)
        .reduce((sum, tx) => sum + tx.amount, 0) / 1_000_000;
      
      const xtzOut = transactions
        .filter(tx => tx.sender?.address === address)
        .reduce((sum, tx) => sum + tx.amount, 0) / 1_000_000;

      const nftTokens = tokens.filter(token => 
        token.token.standard === 'fa2' && 
        token.token.metadata?.image || token.token.metadata?.thumbnailUri
      );
      
      const nftCount = nftTokens.length;
      
      // Collect unique contracts with their aliases
      const contractMap = new Map<string, UniqueContract>();
      transactions.forEach(tx => {
        if (tx.target?.address && tx.target.address !== address) {
          const contract: UniqueContract = {
            address: tx.target.address,
            alias: tx.target.alias
          };
          contractMap.set(tx.target.address, contract);
        }
      });
      
      const uniqueContracts = Array.from(contractMap.values()).slice(0, 10);
      const topNFTs = nftTokens.slice(0, 6);

      return {
        account,
        txCount,
        xtzIn: Math.round(xtzIn * 100) / 100,
        xtzOut: Math.round(xtzOut * 100) / 100,
        firstActivity,
        nftCount,
        uniqueContracts,
        topNFTs,
        stakedBalance: account.stakedBalance,
        unstakedBalance: account.unstakedBalance
      };
    } catch (error) {
      console.error('Error fetching wallet stats:', error);
      throw error;
    }
  }
}

export const tzktApi = new TzKTApiService();