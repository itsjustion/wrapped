import html2canvas from 'html2canvas';

export const downloadWrappedImage = async (elementId: string, filename: string = 'tezos-wrapped.png') => {
  try {
    const element = document.getElementById(elementId);
    if (!element) {
      throw new Error('Element not found');
    }

    const canvas = await html2canvas(element, {
      backgroundColor: '#1a1a1d',
      scale: 2,
      useCORS: true,
      allowTaint: true,
    });

    const link = document.createElement('a');
    link.download = filename;
    link.href = canvas.toDataURL('image/png');
    link.click();
  } catch (error) {
    console.error('Error downloading image:', error);
    alert('Failed to download image. Please try again.');
  }
};

export const shareOnTwitter = (stats: { txCount: number; xtzIn: number; nftCount: number }) => {
  const text = `Just checked out my #TezosWrapped — ${stats.txCount} txs, ${stats.xtzIn} XTZ received, ${stats.nftCount} NFTs collected. Check yours at tezoswrapped.xyz 🧿`;
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`;
  window.open(twitterUrl, '_blank');
};